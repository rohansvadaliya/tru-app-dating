<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\QuestionController;
use App\Http\Controllers\QuestionTypesController;
use App\Http\Controllers\UserController;              


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Route::get('/question',[QusetionController::class,'addquestion']);
// Route::post('/updatequestion',[QusetionController::class,'question']);



// Route::get('/questiontype',[Qusetion_typeController::class,'question']);
// Route::post('/updatetype',[Qusetion_typeController::class,'add_question']);
Route::get('/question-types-add',[QuestionTypesController::class,"addQuestiontype"])->name('question-type-save');
Route::get('/question-type-edit/{id}', [QuestionTypesController::class, "editQuestionType"])->name('question-type-edit');
Route::post('/question-type-save', [QuestionTypesController::class, "saveQuestionType"])->name('question-type-save');
Route::get('/question-type/{msg?}', [QuestionTypesController::class, "indexQuestionType"])->name('question-type');
Route::get('/question-type-delete/{id}', [QuestionTypesController::class, "deleteQuestionType"])->name('question-type-delete');
Route::get('/question-type-view/{id}', [QuestionTypesController::class, "viewQuestionType"])->name('question-type-view');

Route::get('/layout', [QuestionTypesController::class, "insertlayout"])->name('layout');
Route::get('/dashbord', [QuestionTypesController::class, "dashbord"])->name('dashbord');


Route::get('/question-add/{id}', [QuestionController::class, "add_question"])->name('question-save');
Route::get('/question-edit/{id}', [QuestionController::class, "edit_question"])->name('question-edit');
Route::post('/question-save', [QuestionController::class, "save_question"])->name('question-save');
Route::get('/question/{msg?}', [QuestionController::class, "index_question"])->name('question');
Route::get('/question-delete/{id}', [QuestionController::class, "delete_question"])->name('question-delete');
Route::get('/question-view/{id}', [QuestionController::class, "view_question"])->name('question-view');


Route::get('/option-add', [QuestionController::class, "option_add"])->name('option-save');
Route::get('/option-edit/{id}', [QuestionController::class, "option_edit"])->name('option-edit');
Route::post('/option-save', [QuestionController::class, "option_save"])->name('option-save');
Route::get('/option/{msg?}', [QuestionController::class, "option_index"])->name('option');
Route::get('/option-delete/{id}', [QuestionController::class, "option_delete"])->name('option-delete');
Route::get('/option-view/{id}', [QuestionController::class, "option_view"])->name('option-view');


Route::get('/',[UserController::class,"SignUp"])->name('/');
Route::post('/',[UserController::class,"SignUpSubmit"])->name('/');

Route::get('/login',[UserController::class,"login"])->name('/login');
Route::post('/login-submit',[UserController::class,"login_submit"])->name('/login-submit');

Route::get('logout',[UserController::class,"log_out"])->name('/logout');





