<?php

namespace App\Http\Controllers;
use App\Models\QuestionType;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;

class QuestionTypesController extends Controller
{
    public function __construct() {
        $this->middleware(function ($request, $next) {
        $data = $request->session()->get('user_id');
        if (!isset($data)) {
        return redirect()->route('/');
        }
        return $next($request);
        });
        
        }

    public function indexQuestionType(Request $request,$msg = "")
    {
        $data = Session::get('user_id');

        if($data){
            $question_type = QuestionType::all();

            $data2['question_type'] = $question_type;
            $data2['msg'] = $msg;
            return view('/list_question_type',compact('data2'));
        }else{
            return redirect('/');
        }

        // return view('/listquestiontype', ['questiontype' => $questiontype, 'msg=' => $msg]);
    }

    public function addQuestionType(Request $request)
    {
        $data = Session::get('user_id');

        if($data){

            return view('question_type');
        } else {
             return redirect('/');
    }
}

    public function editQuestionType(Request $request, $id)
    {
        $data = Session::get('user_id');

        if($data){

        $question_type = QuestionType::where('id', $id)->get();
        return view('edit_question_type', ['question_type' => $question_type]);
        }else{
            return redirect('/');
        }
    }

    public function viewQuestionType(Request $request, $id)
    {
        $data = Session::get('user_id');

        if($data){

        $question_type = QuestionType::where('id', $id)->get();
        return view('view_question_type', ['question_type' => $question_type]);
        }else{
            return redirect('/');
        }
    }
    
    public function saveQuestionType(Request $request)
    {
        $id =isset($request->id)? $request->id : 0;

        $validateData = $request->validate([
            'name' => 'required',
        ]);
        // print_r($request->id);
        // die;
        if($id != 0){
            // $question_id = $request->input('question_id');
            $name = $request->input('name');
            $check = QuestionType::where([
                ['name','=',$name],
            ])->first();

            if($check){
                return back()->with('success','Question Type Do not Add Please Enter a Correct Question Type');
            }

            $data = Session::get('user_id');

            if($data){

            $question_type = QuestionType::find($id);
      
            $question_type->name = $name;
            $res = $question_type->save();
            $msg = "";
            if ($res) {
                $msg = "Update Question Type Successfully Update";
            }
            return redirect('question-type/' . $msg);
        }else{
            return redirect('/');
        }

        }else{
            $name = $request->input('name');

        $check = QuestionType::where([
            ['name', '=', $name],
        ])->first();

        if($check) {
            // return back()->with('Do Not Enter Duplicate Name.');
            return back()->with('success','QuestionType Do Not Add Please Enter a Correct Type.');
               
        } else {

            $data = Session::get('user_id');

            if($data){

            $question_type = new QuestionType();
            $question_type->name = $request->name;
            $question_type->save();
            // return $questiontype;
            return back()->with('success', 'QuestionType Added Successful.');
            }else{
                return redirect('/');
            }

        }
        }
     }
    public function deleteQuestionType(Request $request, $id)
    {
        $data = Session::get('user_id');

        if($data){

        $question_type = QuestionType::find($id);
        $res = $question_type->delete();
        $msg = "";
        if ($res) {
            $msg = "Deleted Question Type Succesfully";
        }
        return redirect('question-type/' . $msg);
    }else{
        return redirect('/');
    }
    }

    public function insertlayout(Request $request)
    {
        $data =session::get('user_id');
        if($data){

            return view('/layout');
        } else {
             return redirect('/');
        }
    }

    public function dashbord(Request $request)
    {
        $data = Session::get('user_id');

        if($data){
            // if ($request->session()->has('id', 'Email', 'Password')) {

                return view('/dashbord');
            } else {
                 return redirect('/');
    }
}
}

