<?php

namespace App\Http\Controllers;

use App\Models\Question;
use App\Models\QuestionType;
use App\Models\Option;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;

class QuestionController extends Controller
{
    public function __construct() {
        $this->middleware(function ($request, $next) {
        $data = $request->session()->get('user_id');
        if (!isset($data)) {
        return redirect()->route('/');
        }
        return $next($request);
        });
        
        }

    public function index_question(Request $request,$msg="")
    {
        $data = Session::get('user_id');
        if($data){

        $question = Question::all();

        $question = DB::table('question')
        ->join('question_type', 'question.question_type_id', '=', 'question_type.id')
        ->select('question.*', 'question_type.name')
        ->orderBy('id', 'ASC')
        ->get();

        $data = array();
        $data['question'] = $question;
        $data['msg'] = $msg;
        return view('list_question',compact('data'));
    } else {
        return redirect('/');
    }
}

    public function add_question(Request $request)
    {
        $data = Session::get('user_id');
        if($data){

            $question_type = QuestionType::all();
            return view('question',['question_type'=>$question_type]);
        } else {
            return redirect('/');
        }
    }

    public function edit_question(Request $request, $id)
    {
        $data = Session::get('user_id');
        if($data){

        $question = Question::where('id', $id)->get();
        // $questiontype=Questiontype::('id',$questiontype[0]->que_id)->get();
        $question_type = QuestionType::all();
        return view('edit_question', ['question' => $question, 'question_type' => $question_type,'id'=>$id]);
    } else {
        return redirect('/');
    }
}
    
    public function view_question(Request $request, $id)
    {
        $data = Session::get('user_id');
        if($data){

        $question = Question::where('id', $id)->get();

        $question= Question::join('question_type','question.question_type_id','=','question_type.id')
        ->where('question.id',$id)
        ->select('question.id as q_id' ,'question.*','question_type.*')
        ->get();

        return view('view_question', ['question' => $question, 'id' => $id]);
    } else {
        return redirect('/');
    }
}
    
    public function save_question(Request $request)
    {
        $id =isset($request->id) ? $request ->id : 0;

        $validateData = $request->validate([
            'question_id' => 'required',
            'question' => 'required',
        ]);

        if($id != 0)
        {
            $question_id = $request->input('question_id');
            $question = $request->input('question'); 

            $check= Question::where([
                ['question_type_id','=',$question_id],
                ['question','=',$question]
            ])->first();
            if($check)
            {
                return back()->with('success','Question Do Not Add Please Enter a Correct Question.');
            }
            
            /*update Data */
     else{
        $data = Session::get('user_id');

        if($data){

        $question =Question::find($id);
        $question->question_type_id =$request->question_id;
        $question->question =$request->question;
        $question->save();

        $msg = "Updated Question Successfully";

        if(isset($request->option)){

            foreach($request->option as $key=>$values){

                // $optiontype= Option::find($id) ;
                $option = new Option();
                $option->question_id= $question->id;
                $option->option=$values;
                $msg= $option->save();
            } 
        }
            return redirect('question/'.$msg);
    }else{
        return redirect('/');
    }
    }
    }else{ 
        $question_id = $request->input('question_id');
        $question = $request->input('question');
        $name=$request->input('question_type');

            $check = Question::where([
                ['question', '=', $question],
                ['question_type_id','=',$question_id]
            ])->first();

    if($check) {

            return back()->with('success','Question Do Not Add Please Enter a Correct Question.');
        } else {

            /*add a Data */
            $data = Session::get('user_id');

        if($data){
            
            $question = new Question();
            $question->question_type_id = $request->question_id;
            $question->question = $request->question;
            $question->save();

            $msg = "Question Added Successfully";
            
            if(isset($request->option)){
        
                    foreach($request->option as $key => $value){

                     $option = new Option();
                     $option->question_id = $question->id;
                     $option->option = $value;
                     $msg= $option->save();
                }
        }     
        return redirect('question/'.$msg);  
    }else{
        return redirect('/');
    }
            }
        }
    }
    public function delete_question(Request $request, $id)
    { 
        $data = Session::get('user_id');
        if($data){

        $question = Question::find($id);
        $question->delete();

        $msg = "Deleted Option Successfully";
    } else {
        return redirect('/');
    }
    $data= Session::get('user_id');
    if($data){

        if(isset($request->option_type)){

            foreach($request->option_type  as $key=>$values){

                 $option_type = new Option();
                 $msg=$values->delete();
            }
        } else {
            return redirect('/');
        }

        }
        return redirect('option/'.$msg);
}
    public function option_add(Request $request)
    {
        $data = Session::get('user_id');

        if($data){
            $question=Question::all();
      
            return view('option',['question' => $question,]);
        } else {
             return redirect('/');
    }
}

    public function option_edit(Request $request, $id)
    {
        $data = Session::get('user_id');
        if($data){

        $option_type = Option::where('id', $id)->get();
        return view('edit_option', ['option_type' => $option_type]);
        }else{
            return redirect('/');
        }
    }

    public function option_view(Request $request, $id)
    {
        $data = Session::get('user_id');
        if($data){

        $option_type = Option::where('id', $id)->get();
        return view('view_option', ['option_type' => $option_type]);
        }else{
            return redirect('/');
        }
    }

    public function option_save(Request $request)
    {
        $id =isset($request->id)? $request->id : 0;

        $validateData = $request->validate([
            'question_id' => 'required',
            'option'=>'required',
            
        ]); 
            if($id != 0){

            $question_id = $request->input('question_id');
            $option=$request->input('option');

            $option_type = Option::find($id);

            $option_type->question_id = $question_id;
            $option_type->option=$option;
            $res = $option_type->save();

            $msg = "";
            if ($res) {
                $msg = "Update Option Successfully Update";
            }
            return redirect('option/' . $msg);     
        }  
         else {

            $option_type = new Option();
            $option_type->question_id = $request->question_id;
            $option_type->option=$request->option;
            $option_type->save();
            // return $questiontype;
            return back()->with('success', 'Option Added Successful.');
        } 
     }
    // public function option_delete(Request $request, $id)
    // {
    //     $option_type = Option::find($id);
    //     $res = $option_type->delete();
    //     $msg = "";
    //     if ($res) {
    //         $msg = "Delted Option Type Succesfully";
    //     }
    //     return redirect('option/' . $msg);
    // }

    public function option_index(Request $request,$msg = "")
    {

        $data = Session::get('user_id');

        if($data){
            $option_type = Option::all();

            $option_type = Option :: join('question','options.question_id','=','question.id')
            ->select('options.id as option_id','options.*','question.question')
            ->orderBy('option_id','ASC')
            ->get();
    
            $data=array();
            $data['option_type'] = $option_type;
            $data['msg'] = $msg;
            return view('/list_option',compact('data'));
            
        } else {
             return redirect('/');
  }

}
}
