<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Session;


class UserController extends Controller
{
    public function SignUp(Request $request)
    {
        $data = $request->session()->get('user_id');
        if (isset($data)) {
            return redirect()->route('dashbord');
        }else{
            return view('sign_up');
        }
    }

    public function SignUpSubmit(Request $request)
    {
        $validateData = $request->validate([
            'Full_name' => 'required',
            'User_name' => 'required',
            'Password'=>'required',
            'Email' =>'required',
        ]);

        $Full_name = $request->input('Full_name');
        $User_name=$request->input('User_name');
        $Password=$request->input('Password');
        $Email=$request->input('Email');

        $check = User::where([
            ['UserName','=',$User_name],
            ['Password','=',$Password],
            ['Email','=',$Email],
        ])->first();

        if($check){
            return back()->with('success','Do Not Add Duplicate Email Enter');
        }

        $SignUp = new User();
        $SignUp->FullName = $request->Full_name;
        $SignUp->UserName =$request->User_name;
        // $SignUp->Password-> hash::make ($request->Password);
        $SignUp->Password= $request->Password;
        $SignUp->Email =$request->Email;
        $res= $SignUp->save();
        $msg="";
        if($res){
            $msg="Sign Up Successfully.";
        }
        return redirect('/login');


    }
    public function login(Request $request)
    {
    
        if ($request->session()->has('id','password','email')) {
             return redirect('/dashbord');
        } else {
             return view('login', ['loginmsg' => '']);
        }
    }

    public function login_submit(Request $request)
    {
        $validateData = $request->validate([
            'Password' =>'required',
            'Email' =>'required',
        ]);
    
        $Password = $request->input('Password');
        $Email= $request->input('Email');
        // echo $cmbuser;
        // if ($cmbuser == "User") {

            $check = User::where([
                ['Password','=',$Password],
                ['Email','=',$Email]
            ])->first();
            // echo $check->id;

            
            if ($check) {
                // $request->session()->put('id', $check->id);

                Session::put("user_id",$check->id);
                $request->session()->put('id',$check->id);
                // return session();
                // $request->session()->put('name', $check->FullName);
                // $request->session()->put('username',$check->UserName);
                $request->session()->put('password',$check->$Password);
                $request->session()->put('email',$check->Email);
                // echo "<pre>";
                // print_r($check);
                // die;
                return redirect('/dashbord');
            } else {
                return view('login', ['loginmsg' => 'Invalid Username & Password.']);
            }
        }

        public function log_out(Request $request)
    {
         $request->session()->flush();
        return redirect('login');
    }
 }

