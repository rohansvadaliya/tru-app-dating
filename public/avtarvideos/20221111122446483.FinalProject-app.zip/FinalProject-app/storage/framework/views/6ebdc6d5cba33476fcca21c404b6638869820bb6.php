<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 style="color:rgb(0, 140, 255);">Edit Question Type</h1>
    <?php $__currentLoopData = $question_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form class="form-inline" method="post" action="/question-type-save?id=<?php echo e($row->id); ?>">
        <?php echo e(Session::get('success')); ?>

        <?php echo csrf_field(); ?>
        
        <div class="form-group">
            <label for="Question type">Name</label>
            <input type="text" name="name" value="<?php echo e($row->name); ?>"
                class="form -control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" placeholder="name">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="eroor invalid-feedback">Please Enter a Name.</span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <br><br>
        <div class="form-group">
            <input type="submit" value="submit" class="btn btn-primary">
            
        </div>
    </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/imac/.Trash/prinsi/23question-app/resources/views/edit_question_type.blade.php ENDPATH**/ ?>