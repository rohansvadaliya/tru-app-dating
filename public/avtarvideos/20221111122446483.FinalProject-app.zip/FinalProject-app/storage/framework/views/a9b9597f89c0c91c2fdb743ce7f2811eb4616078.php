<?php $__env->startSection('content'); ?>
<div class="container">
    <table border="2">
        <div class="row-12">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h1 style="color:rgb(0, 140, 255);">View Question Type</h1>
                    </div>
                </div>
                <table border="2">
                    <div class="container">
                        <?php $__currentLoopData = $question_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>Question Id</td>
                            <td><?php echo e($row->id); ?></td>
                        </tr>
                        <tr>
                            <td>Name</td>
                            <td><?php echo e($row->name); ?></td>
                        </tr>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </table>
            </div>
        </div>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/imac/.Trash/prinsi/23question-app/resources/views/view_question_type.blade.php ENDPATH**/ ?>