<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="http://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <title>Show CRUD using Ajax</title>
    </head>
    <body>
        <br><br>
        <div class="container">
            <div class="row">
                <div class="col-md-10">
                    <table class="table table-bordered">
                        <thead>
                            <td>ID</td>
                            <td>Name</td>
                            <td>Action</td>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $Data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->id); ?></td>
                                <td><?php echo e($row->name); ?></td>
                                <td><a href="<?php echo e(url('/edit'.$row->id)); ?>" target="_blank" class="btn btn-secondary">Edit</a>
                                <a href="<?php echo e(url('/delete'.$row->id)); ?>" target="_blank" class="btn btn-danger">Delete</a>
                            </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
            </div>
        </div>
        
    </body>
    </html>
<?php /**PATH D:\question-app\resources\views/show.blade.php ENDPATH**/ ?>