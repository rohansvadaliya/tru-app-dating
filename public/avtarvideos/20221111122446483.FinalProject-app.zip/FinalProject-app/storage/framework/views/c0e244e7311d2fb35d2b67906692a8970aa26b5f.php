<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="http://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <title>CRUD using Ajax</title>
    </head>
    <body>
        <br><br>
        <div class="container">
            <div class="row">
                <div class="col-md-10">
                    <form action="formsubmit" method="post">
                        <?php echo csrf_field(); ?>
                        
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="name" id="name" name="name" class="from-control" placeholder="name">
                        </div>
                        <button type="submit" class="btn-btn-primary" id="submit">Submit</button>
                        <a href="/show" class="btn btn-secondary">show</a>


                    </form>
                </div>
            </div>
        </div>
        <script>
            $('#submit').click(function(){
                $.ajax({
                    url:'formsubmit',
                    data: $('question').serialize(),
                    type:'post',
                    success:function(result){
                        alert(result);

                    }
                });
            });
         </script>
    </body>
    </html>
<?php /**PATH D:\question-app\resources\views/question.blade.php ENDPATH**/ ?>