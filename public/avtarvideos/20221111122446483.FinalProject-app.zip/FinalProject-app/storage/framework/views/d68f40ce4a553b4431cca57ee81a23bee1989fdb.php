<html>

<head>
    <title>"Question Type Book"</title>
</head>

<body>
    <form method="post" action="/updatetype">
    <label for="txtid">Type Id</label>
    <input type="text" name="txtid" id="txtid" placeholder="txtid">
    <br>
    <label for="txtname">Question Id</label>
    <input type="text" name="queid" id="queid" placeholder="queid">
    <br>
    <label for="txtname">Question Type</label>
    <select class="form-control" name="questiontype" id="questiontype">
        <option>text</option>
        <option>file </option>
        <option>option</option>
    </select>
    <br>
    <label fro="txtqusetion">Question </label>
    <input type="txtquestion" name="txtquestion" placeholder="txtquestion">
    <br>
    <input type="submit" value="submit" class="btn btn-primary" />

</body>

</html>
<?php /**PATH D:\question-app\resources\views/type.blade.php ENDPATH**/ ?>