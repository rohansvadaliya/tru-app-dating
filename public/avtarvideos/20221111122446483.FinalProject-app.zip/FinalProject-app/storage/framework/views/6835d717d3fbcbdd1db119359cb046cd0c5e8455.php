<html lang="en">

<head>
    <title>CSS Website Layout</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Answer">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            margin: 0;
            font-family: "Lato", sans-serif;
        }

        .sidebar {
            margin: 0;
            padding: 0;
            width: 200px;
            background-color: #f1f1f1;
            position: fixed;
            height: 100%;
            overflow: auto;
        }

        .sidebar a {
            display: block;
            color: black;
            padding: 16px;
            text-decoration: none;
        }

        .sidebar a.active {
            background-color: #0a5a8b;
            color: white;
        }

        .sidebar a:hover:not(.active) {
            background-color: #555;
            color: white;
        }

        div.content {
            margin-left: 200px;
            padding: 1px 16px;
            height: 1000px;
        }

        @media  screen and (max-width: 700px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            .sidebar a {
                float: left;
            }

            div.content {
                margin-left: 0;
            }
        }

        @media  screen and (max-width: 400px) {
            .sidebar a {
                text-align: center;
                float: none;
            }
        }

        /* nevebar */
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
        }

        /* Style the header */
        .header {
            background-color: #f1f1f1;
            padding: 20px;
            text-align: center;
        }

        /* Style the top navigation bar */
        .topnav {
            overflow: hidden;
            background-color: rgb(246, 249, 252);
        }

        .topnav-right {
            float: right;
        }

        /* Style the topnav links */
        .topnav a {
            float: left;
            display: block;
            color: #27a1da;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        /* Change color on hover */
        .topnav a:hover {
            background-color: rgb(221, 221, 221);
            color: rgb(61, 139, 208);
        }
        div class="log-out"{
            text-align:right;

        }
    </style>
</head>




<div class="topnav">
    <a class="active" href="#home">WebSite Name</a>

    <div class="log-out">
    <a href="/logout" class="dropdown-item">
        <i class="fas fa-sign-out-alt"></i> Log Out
    </a>

</div>


        
</div>

<div class="sidebar">
    
    <a href="/dashbord" class="nav-link<?php echo e(Request::is('dashbord')? 'active':''); ?>">
        <i class="far fa -circle nav-icon"></i>
        <p>Dashbord</p>
    </a>

    <a href="/question-type" class="nav-link<?php echo e(Request::is('question-type')? 'active':''); ?>">
        <i class="far fa -circle nav-icon"></i>
        <p>Question Type List</p>
    </a>
    <a href="/question" class="nav-link<?php echo e(Request::is('question')? 'active':''); ?>">
        <i class="far fa -circle nav-icon"></i>
        <p>Question List</p>
    </a>

    <a href="/option" class="nav-link<?php echo e(Request::is('/option')? 'active':''); ?>">
        <i class="far fa -circle nav-icon"></i>
        <p>Option List</p>
    </a>


    

</div>
<div clas="conatiner">
    

    <?php echo $__env->yieldContent("content"); ?>
</div>
</body>

</html>

<?php /**PATH /Users/imac/.Trash/prinsi/23question-app/resources/views/layout.blade.php ENDPATH**/ ?>