<html>
    <head>
        <title>"Question Book"</title>
    </head>
        <body>
            <form method="post" action="/updatequestion">
            <label for="txtid">Id</label>
            <input type="text" name="txtid" id ="txtid" placeholder="txtid">
            <br>
            <label for="txtname">name</label>
            <input type="text" name="txtname" id="txtname" placeholder="txtname">
            <br>
            <input type="submit" value="submit" class="btn btn-primary"/>
            </form>
        </body>
        </html>
<?php /**PATH D:\question-app\resources\views/qusetionbook.blade.php ENDPATH**/ ?>