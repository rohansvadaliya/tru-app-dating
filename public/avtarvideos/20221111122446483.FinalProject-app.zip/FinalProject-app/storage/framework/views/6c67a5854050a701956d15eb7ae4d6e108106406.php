<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row-12">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h1 style="color:rgb(0, 140, 255);">List Of All Option Type</h1>
                </div>
                <div class="bs-example">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 bg-light text-right">
                                <a href="/option-add"
                                    class="nav-link<?php echo e(Request::is ('option-add/{id}')? 'active':''); ?>">
                                    <button type="button" class="btn btn-primary">Add Type</button>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card- body">
                    <?php if($data['msg']!=""): ?>
                    <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                        <h5><i class="icon fas fa-chack"></i>Alert!</h5>
                        <?php echo e($data['msg']); ?>

                    </div>
                    <?php endif; ?>

                    <table border="2">
                        <tr>
                            <th> Id </th>
                            <th> Question Id </th>
                            <th> Option </th>
                            
                            
                            <th>Edit</th>
                            <th>Delete</th>
                            <th>View</th>
                        </tr>
                        <?php $__currentLoopData = $data['option_type']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($row->option_id); ?></td>
                            <td><?php echo e($row->question_id); ?>

                            <td><?php echo e($row->option); ?></td>
                            
                            
                            
                            <td><a href="/option-edit/<?php echo e($row->id); ?>" taget="_blank" class="btn btn-warning">Edit</td>
                            <td><a href="/option-delete/<?php echo e($row->id); ?>" taget="blank" class="btn btn-danger">Delete</td>
                            <td><a href="/option-view/<?php echo e($row->id); ?>" target="_blank" class="btn btn-Primary">View</td>
                        </tr>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/imac/.Trash/prinsi/23question-app/resources/views//list_option.blade.php ENDPATH**/ ?>