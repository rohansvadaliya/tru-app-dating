<?php $__env->startSection('content'); ?>

<style type="text/css">
    input[type="button"] {
        box-shadow: none;
    }

    .btn:focus {
        outline: none;
        box-shadow: none;
    }
</style>
<div class="container">
    <div class="row-12">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h1 style="color:rgb(0, 140, 255);">List Of All Question</h1>
                </div>
                <div class="bs-example">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 bg-light text-right">
                                <a href="/question-add/{id}"
                                    class="nav-link<?php echo e(Request::is ('question-add/{id}')? 'active':''); ?>">
                                    <button type="button" class="btn btn-primary">Add Question</button>
                                    
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card- body">
                    <?php if($data['msg']!=""): ?>
                    <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                        <h5><i class="icon fas fa-chack"></i>Alert!</h5>
                        <?php echo e($data['msg']); ?>

                    </div>
                    <?php endif; ?>
                    <table border="2">
                        <tr>
                            <th>Question Id</th>
                            <th>Question Type</th>
                            <th>Question</th>

                            <th>Edit</th>
                            <th>Delete</th>
                            <th>View</th>
                        </tr>
                        <?php $__currentLoopData = $data['question']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($row->id); ?></td>
                            <td><?php echo e($row->name); ?></td>
                            <td><?php echo e($row->question); ?></td>

                            <td><a href="/question-edit/<?php echo e($row->id); ?>" taget="_blank" class="btn btn-warning">Edit</a>
                            </td>

                            <td><a href="/question-delete/<?php echo e($row->id); ?>" taget="blank"
                                    class="btn btn-danger">Delete</a></td>

                            <td><a href="/question-view/<?php echo e($row->id); ?>" target="_blank" class="btn btn-Primary">View</a>
                            </td>
                        </tr>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/imac/.Trash/prinsi/23question-app/resources/views/list_question.blade.php ENDPATH**/ ?>