<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 style="color:rgb(0, 140, 255);">Add Question</h1>
    <form class="form-inline" method="post" action="/question-save">
        <div class="card-body">
            <?php echo e(Session::get('success')); ?>

            <?php echo csrf_field(); ?>
            <br>
            <div class="form-group">
                <label for="select question">Question Type</label>
                <select class="form-control" <?php $__errorArgs = ['question_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> name="question_id"
                    id="question_id">
                    <?php $__currentLoopData = $question_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allquestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($allquestion->id); ?>"><?php echo e($allquestion->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__errorArgs = ['question_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="error invalid-feedback"> Please Enter a Valid Question Id.</span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </select>
            </div>
            <br><br>
            
            <div id="test"></div>
            <div class="form-group">
                <label for="select question">Question</label>
                
                    <input type="text" class="form-control" name="question"
                        class="form-control <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="question"
                        placeholder="question">
                    <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="error invalid-feedback">Please enter a question</span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <br><br>
            <div class="form-group">
                <input type="submit" value="submit" class="btn btn-primary">
            </div>
            
            <div class="form-group">
                <button type="button" class="btn btn-primary" onclick="return append();" id="add_btn" disabled><i
                        class="glyphicon glyphicon-plus"></i></button>
            </div>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script type="text/javascript" src="dist/js/jquery-2.1.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript">

    $("#question_id").on("change", function(){
        if ($('#question_id').val() == 3)
        {
            $('#add_btn').prop('disabled', false);
        }
    });

    function append(){
        var html='';
            
            html+=" <input type='text' class='form-control' name='option[]'id='option'>";

            $('#test').append(html);
    }

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/imac/.Trash/prinsi/23question-app/resources/views/question.blade.php ENDPATH**/ ?>