<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 style="color:rgb(0, 140, 255);"> Add Question Type</h1>
    <form class="form-inline" method="post" action="/question-type-save">
        <div class="card-body">

            <?php echo e(Session::get('success')); ?>

            
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name"> Name </label>
                <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name"
                    placeholder="Enter name">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="error invalid-feedback">Please enter Name.</span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <br><br>
            <div class="form-group">
                <input type="submit" value="submit" class="btn btn-primary">
                
            </div>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/imac/.Trash/prinsi/23question-app/resources/views/question_type.blade.php ENDPATH**/ ?>