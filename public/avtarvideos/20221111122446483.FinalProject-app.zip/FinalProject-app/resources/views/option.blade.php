@extends('layout')

@section('content')
<div class="container">
    <h1 style="color:rgb(0, 140, 255);"> Add Option</h1>
    <form class="form-inline" method="post" action="/option-save">
        <div class="card-body">

            {{ Session::get('success') }}
            {{-- {{ Session::get('success') }} --}}
            @csrf
            <div class="form-group">
                <label for="name"> question_id</label>
                {{-- <input type="" name="question_id" class="form-control @error('question_id') is-invalid @enderror" --}}
                <select class="form-control" @error('question_id') is-invalid @enderror name="question_id"
                    id="question_id" placeholder="Enter question_id">
                    @foreach($question as $alloption)
                    <option value="{{ $alloption->id }}">{{ $alloption->question}}</option>
                    @endforeach
                @error('question_id')
                <span class="error invalid-feedback">Please enter question id</span>
                @enderror
            </select>
            </div>
            <br><br>
            <div class="form-group">
                <label for="option">Option</label>
                <input type="text" name="option" class="form-control @error ('option') is- invalid @enderror"
                    id="option" placeholder="Enter option">
                @error('option')
                <span class="error invalid-feedback"> Please Enter Option</span>
                @enderror
            </div>

            <br><br>
            <div class="form-group">
                <input type="submit" value="submit" class="btn btn-primary">
                {{-- <button onclick="myFunction()">Submit</button> --}}
            </div>
        </div>
    </form>
</div>
{{-- <script>
    function myFunction() {
          alert("Question Type Add Suceessfully!");
        }
</script> --}}
@endsection
