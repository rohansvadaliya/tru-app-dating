@extends('layout')

@section('content')
<div class="container">
    <div class="row-12">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h1 style="color:rgb(0, 140, 255);">List Of All Option Type</h1>
                </div>
                <div class="bs-example">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 bg-light text-right">
                                <a href="/option-add"
                                    class="nav-link{{ Request::is ('option-add/{id}')? 'active':'' }}">
                                    <button type="button" class="btn btn-primary">Add Type</button>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card- body">
                    @if($data['msg']!="")
                    <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                        <h5><i class="icon fas fa-chack"></i>Alert!</h5>
                        {{ $data['msg'] }}
                    </div>
                    @endif

                    <table border="2">
                        <tr>
                            <th> Id </th>
                            <th> Question Id </th>
                            <th> Option </th>
                            {{-- <th>Categories Id</th> --}}
                            {{-- <th>Add</th> --}}
                            <th>Edit</th>
                            <th>Delete</th>
                            <th>View</th>
                        </tr>
                        @foreach ($data['option_type'] as $row)
                        <tr>
                            <td>{{ $row->option_id }}</td>
                            <td>{{ $row->question_id }}
                            <td>{{ $row->option }}</td>
                            {{-- <td>{{$row->question}}</td> --}}
                            {{-- <td>{{ $row->cat_id }}</td> --}}
                            {{-- <td><a href="/question/{{ $row->id }}">Add</td> --}}
                            <td><a href="/option-edit/{{ $row->id }}" taget="_blank" class="btn btn-warning">Edit</td>
                            <td><a href="/option-delete/{{ $row->id }}" taget="blank" class="btn btn-danger">Delete</td>
                            <td><a href="/option-view/{{ $row->id }}" target="_blank" class="btn btn-Primary">View</td>
                        </tr>
                        {{-- <div class="btn-group">
                            <a href="/editanswer/{{ $row->answer_id }}">
                                <button type="button" class="btn btn-default">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </a>
                        </div> --}}
                        @endforeach
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection