@extends('layout')

@section('content')
<div class="container">
    <h1 style="color:rgb(0, 140, 255);">Edit Question Type</h1>
    @foreach ($question_type as $row)
    <form class="form-inline" method="post" action="/question-type-save?id={{ $row->id }}">
        {{ Session::get('success') }}
        @csrf
        {{-- <div class="form-group">
            <label> Question Type Id</label>
            <input type="text" name="question_id" palceholder="question_id" value="{{ $row->id }}">
        </div>
        <br><br> --}}
        <div class="form-group">
            <label for="Question type">Name</label>
            <input type="text" name="name" value="{{ $row->name}}"
                class="form -control @error('name') is-invalid @enderror" id="name" placeholder="name">
            @error ('name')
            <span class="eroor invalid-feedback">Please Enter a Name.</span>
            @enderror
        </div>
        <br><br>
        <div class="form-group">
            <input type="submit" value="submit" class="btn btn-primary">
            {{-- <button onclick="myFunction()">Submit</button> --}}
        </div>
    </form>
    @endforeach
</div>
{{-- <script>
    function myFunction() {
          alert("Edit Question Type Successfully!");
        }
</script> --}}
@endsection