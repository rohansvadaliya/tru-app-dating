{{-- <html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Answer">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body>
    <div class="row-12">
        <div class="col-12 col-sm-6 col-ml-3">
            <div class="info=box">
                <span class="info-box-icon bg- info-elevation-1"><i class="fas  fa-user-alt"></i></span>

                <div class="info-box-content">
                    <span class="info-box-text">Question</span>
                    <span class="info-box-number">
                    </span>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-ml-3">
            <div class="info=box">
                <span class="info-box-icon bg- info-elevation-1"><i class="fas  fa-user-alt"></i></span>

                <div class="info-box-content">
                    <span class="info-box-text">Answer</span>
                    <span class="info-box-number">
                    </span>
                </div>
            </div>
        </div>
        <div class="info=box">
            <span class="info-box-icon bg- info-elevation-1"><i class="fas  fa-user-alt"></i></span>

            <div class="info-box-content">
                <span class="info-box-text">Categories</span>
                <span class="info-box-number">
                </span>
            </div>
        </div>
    </div>
    <div class="info=box">
        <span class="info-box-icon bg- info-elevation-1"><i class="fas  fa-user-alt"></i></span>

        <div class="info-box-content">
            <span class="info-box-text">Question</span>
            <span class="info-box-number">
            </span>
        </div>
    </div>
    </div>
    </head>
</body>

</html> --}}
@extends('layout',['title'=>'Dashboard'])

@section('content')
<div class="content">
    {{-- <div class="col-12 col-sm-6 col-md-3">
        <div class="info-box">
            <span class="info-box-icon-bg-info elevation-1"><i class="fas fa-user-alt"></i></span>

            <div class="info-box-content"> --}}
                {{-- <span class="info-box-text">Answer</span> --}}
                <div class="card-header">
                    <h1 style="color:rgb(0, 140, 255);">WelCome</h1>
                </div>
                {{--
            </div>
        </div> --}}
    </div>
    @endsection
    {{-- <div class="row">
        <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box">
                <span class="info-box-icon-bg-info elevation-1"><i class="fas fa-user-alt"></i></span>

                <div class="info-box-content">
                    <span class="info-box-text">Question</span>
                    <span class="info-box-number">
                        {{4000}}
                    </span>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box">
                <span class="info-box-icon-bg-info elevation-1"><i class="fas fa-user-alt"></i></span>

                <div class="info-box-content">
                    <span class="info-box-text">Answer</span>
                    <span class="info-box-number">
                        {{2000}}
                    </span>
                </div>
            </div>
        </div>
        @endsection --}}

        {{--

        <head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body {
                    margin: 0;
                    font-family: "Lato", sans-serif;
                }

                .sidebar {
                    margin: 0;
                    padding: 0;
                    width: 200px;
                    background-color: #f1f1f1;
                    position: fixed;
                    height: 100%;
                    overflow: auto;
                }

                .sidebar a {
                    display: block;
                    color: black;
                    padding: 16px;
                    text-decoration: none;
                }

                .sidebar a.active {
                    background-color: #04AA6D;
                    color: white;
                }

                .sidebar a:hover:not(.active) {
                    background-color: #555;
                    color: white;
                }

                div.content {
                    margin-left: 200px;
                    padding: 1px 16px;
                    height: 1000px;
                }

                @media screen and (max-width: 700px) {
                    .sidebar {
                        width: 100%;
                        height: auto;
                        position: relative;
                    }

                    .sidebar a {
                        float: left;
                    }

                    div.content {
                        margin-left: 0;
                    }
                }

                @media screen and (max-width: 400px) {
                    .sidebar a {
                        text-align: center;
                        float: none;
                    }
                }
            </style>
        </head>

        <body>

            <div class="sidebar">
                <a class="active" href="#home">Home</a>
                <a href="#news">News</a>
                <a href="#contact">Contact</a>
                <a href="#about">About</a>
            </div>
            @endsection --}}