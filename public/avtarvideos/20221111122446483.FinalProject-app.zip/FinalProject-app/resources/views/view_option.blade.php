@extends('layout')

@section('content')
<div class="container">
    <table border="2">
        <div class="row-12">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h1 style="color:rgb(0, 140, 255);">View Option Type</h1>
                    </div>
                </div>
                <table border="2">
                    <div class="container">
                        @foreach ($option_type as $row)
                        <tr>
                            <td>Option Id</td>
                            <td>{{ $row->id }}</td>
                        </tr>
                        <tr>
                            <td>question Id</td>
                            <td>{{ $row->question_id }}</td>
                        </tr>
                        <tr>
                            <td>Option</td>
                            <td>{{ $row->option}}</td>
                        </tr>
                        {{-- <div class="btn-group">
                            <a href="/editanswer/{{ $row->answer_id }}">
                                <button type="button" class="btn btn-default">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </a>
                        </div> --}}
                        @endforeach
                    </div>
                </table>
            </div>
        </div>
        @endsection