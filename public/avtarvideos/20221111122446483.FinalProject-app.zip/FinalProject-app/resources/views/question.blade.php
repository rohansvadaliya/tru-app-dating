@extends('layout')

@section('content')
<div class="container">
    <h1 style="color:rgb(0, 140, 255);">Add Question</h1>
    <form class="form-inline" method="post" action="/question-save">
        <div class="card-body">
            {{ Session::get('success') }}
            @csrf
            <br>
            <div class="form-group">
                <label for="select question">Question Type</label>
                <select class="form-control" @error('question_id') is-invalid @enderror name="question_id"
                    id="question_id">
                    @foreach($question_type as $allquestion)
                    <option value="{{ $allquestion->id }}">{{ $allquestion->name }}</option>
                    @endforeach
                    @error('question_id')
                    <span class="error invalid-feedback"> Please Enter a Valid Question Id.</span>
                    @enderror
                </select>
            </div>
            <br><br>
            {{-- <div class="form-group">
                <input type="hidden" class="form-control" name="option" id="option">
            </div> --}}
            <div id="test"></div>
            <div class="form-group">
                <label for="select question">Question</label>
                {{-- <select class="form-control" id="txtquestion" name="txtquestion"> --}}
                    <input type="text" class="form-control" name="question"
                        class="form-control @error('question') is-invalid @enderror" id="question"
                        placeholder="question">
                    @error('question')
                    <span class="error invalid-feedback">Please enter a question</span>
                    @enderror
            </div>
            <br><br>
            <div class="form-group">
                <input type="submit" value="submit" class="btn btn-primary">
            </div>
            {{-- <button id="appendBtn">Append</button> --}}
            <div class="form-group">
                <button type="button" class="btn btn-primary" onclick="return append();" id="add_btn" disabled><i
                        class="glyphicon glyphicon-plus"></i></button>
            </div>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script type="text/javascript" src="dist/js/jquery-2.1.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript">

    $("#question_id").on("change", function(){
        if ($('#question_id').val() == 3)
        {
            $('#add_btn').prop('disabled', false);
        }
    });

    function append(){
        var html='';
            
            html+=" <input type='text' class='form-control' name='option[]'id='option'>";

            $('#test').append(html);
    }

</script>
@endsection