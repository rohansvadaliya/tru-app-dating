@extends('layout')

@section('content')
<div class="container">
    <h1 style="color:rgb(0, 140, 255);"> Add Question Type</h1>
    <form class="form-inline" method="post" action="/question-type-save">
        <div class="card-body">

            {{ Session::get('success') }}
            {{-- {{ Session::get('success') }} --}}
            @csrf
            <div class="form-group">
                <label for="name"> Name </label>
                <input type="text" name="name" class="form-control @error('name') is-invalid @enderror" id="name"
                    placeholder="Enter name">
                @error('name')
                <span class="error invalid-feedback">Please enter Name.</span>
                @enderror
            </div>
            <br><br>
            <div class="form-group">
                <input type="submit" value="submit" class="btn btn-primary">
                {{-- <button onclick="myFunction()">Submit</button> --}}
            </div>
        </div>
    </form>
</div>
{{-- <script>
    function myFunction() {
          alert("Question Type Add Suceessfully!");
        }
</script> --}}
@endsection