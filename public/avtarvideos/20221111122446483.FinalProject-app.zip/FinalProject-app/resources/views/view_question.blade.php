@extends('layout')

@section('content')
<div class="container">
    <div class="row-12">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h1 style="color:rgb(0, 140, 255);">View Question</h1>
                </div>
            </div>
            <table border="2">
                <div class="container">
                    @foreach ($question as $row)
                    <tr>
                        <td>Question Id</td>
                        <td>{{ $row->q_id }}</td>
                    </tr>
                    <tr>
                        <td>Question Type Id </td>
                        <td>{{ $row->question_type_id }}</td>
                    </tr>
                    <tr>
                        <td>Question Type</td>
                        <td>{{ $row->name}}</td>
                    </tr>
                    <tr>
                        <td>question</td>
                        <td>{{ $row->question }}</td>
                    </tr>
                    {{-- <div class="btn-group">
                        <a href="/editanswer/{{ $row->answer_id }}">
                            <button type="button" class="btn btn-default">
                                <i class="fas fa-edit"></i>
                            </button>
                        </a>
                    </div> --}}
                    @endforeach
                    <div>
            </table>
        </div>
    </div>
</div>
@endsection