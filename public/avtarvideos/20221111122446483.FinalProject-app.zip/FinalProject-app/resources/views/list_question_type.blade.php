{{-- <html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="listanswer">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            margin: 0;
            font-family: "Lato", sans-serif;
        }

        .sidebar {
            margin: 0;
            padding: 0;
            width: 200px;
            background-color: #f1f1f1;
            position: fixed;
            height: 100%;
            overflow: auto;
        }

        .sidebar a {
            display: block;
            color: black;
            padding: 16px;
            text-decoration: none;
        }

        .sidebar a.active {
            background-color: #0a5a8b;
            color: white;
        }

        .sidebar a:hover:not(.active) {
            background-color: #555;
            color: white;
        }

        div.content {
            margin-left: 200px;
            padding: 1px 16px;
            height: 1000px;
        }

        @media screen and (max-width: 700px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            .sidebar a {
                float: left;
            }

            div.content {
                margin-left: 0;
            }
        }

        @media screen and (max-width: 400px) {
            .sidebar a {
                text-align: center;
                float: none;
            }
        }
    </style>
    <style>
        table,
        th,
        td {
            border: 1px solid;
        }
    </style>
</head>

<body>
    <div class="sidebar">
        <a class="active" href="#home">Home</a>
        <a href="#news">News</a>
        <a href="#contact">Contact</a>
        <a href="#about">About</a>
    </div> --}}
    @extends('layout')

    @section('content')
    <div class="container">
        <div class="row-12">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h1 style="color:rgb(0, 140, 255);">List Of All Question Type</h1>
                    </div>
                    <div class="bs-example">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12 bg-light text-right">
                                    <a href="/question-types-add"
                                        class="nav-link{{ Request::is ('question-types-add')? 'active':'' }}">
                                        <button type="button" class="btn btn-primary">Add Question Type</button>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card- body">
                        @if($data2['msg']!="")
                        <div class="alert alert-success alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <h5><i class="icon fas fa-chack"></i>Alert!</h5>
                            {{ $data2['msg'] }}
                        </div>
                        @endif

                        <table border="2">
                            <tr>
                                <th> Id </th>
                                <th> Name </th>
                                {{-- <th>Categories Id</th> --}}
                                {{-- <th>Add</th> --}}
                                <th>Edit</th>
                                <th>Delete</th>
                                <th>View</th>
                            </tr>
                            @foreach ($data2['question_type'] as $row)
                            <tr>
                                <td>{{ $row->id }}</td>
                                <td>{{ $row->name}}</td>
                                {{-- <td>{{$row->question}}</td> --}}
                                {{-- <td>{{ $row->cat_id }}</td> --}}
                                {{-- <td><a href="/question/{{ $row->id }}">Add</td> --}}
                                <td><a href="/question-type-edit/{{ $row->id }}" taget="_blank"
                                        class="btn btn-warning">Edit</td>
                                <td><a href="/question-type-delete/{{ $row->id }}" taget="_blank"
                                        class="btn btn-danger">Delete</td>
                                <td><a href="/question-type-view/{{ $row->id }}" target="_blank"
                                        class="btn btn-Primary">View</td>
                            </tr>
                            {{-- <div class="btn-group">
                                <a href="/editanswer/{{ $row->answer_id }}">
                                    <button type="button" class="btn btn-default">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                </a>
                            </div> --}}
                            @endforeach
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endsection