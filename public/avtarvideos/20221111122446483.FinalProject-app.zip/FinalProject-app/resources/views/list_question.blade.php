@extends('layout')

@section('content')

<style type="text/css">
    input[type="button"] {
        box-shadow: none;
    }

    .btn:focus {
        outline: none;
        box-shadow: none;
    }
</style>
<div class="container">
    <div class="row-12">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h1 style="color:rgb(0, 140, 255);">List Of All Question</h1>
                </div>
                <div class="bs-example">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 bg-light text-right">
                                <a href="/question-add/{id}"
                                    class="nav-link{{ Request::is ('question-add/{id}')? 'active':''}}">
                                    <button type="button" class="btn btn-primary">Add Question</button>
                                    {{-- <button onclick="functionToExecute()">Add Question</button> --}}
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card- body">
                    @if($data['msg']!="")
                    <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                        <h5><i class="icon fas fa-chack"></i>Alert!</h5>
                        {{ $data['msg'] }}
                    </div>
                    @endif
                    <table border="2">
                        <tr>
                            <th>Question Id</th>
                            <th>Question Type</th>
                            <th>Question</th>

                            <th>Edit</th>
                            <th>Delete</th>
                            <th>View</th>
                        </tr>
                        @foreach ($data['question'] as $row)
                        <tr>
                            <td>{{ $row->id }}</td>
                            <td>{{ $row->name }}</td>
                            <td>{{ $row->question }}</td>

                            <td><a href="/question-edit/{{ $row->id }}" taget="_blank" class="btn btn-warning">Edit</a>
                            </td>

                            <td><a href="/question-delete/{{ $row->id }}" taget="blank"
                                    class="btn btn-danger">Delete</a></td>

                            <td><a href="/question-view/{{ $row->id }}" target="_blank" class="btn btn-Primary">View</a>
                            </td>
                        </tr>

                </div>
                @endforeach
                </table>
            </div>
        </div>
    </div>
</div>
</div>
@endsection
