@extends('layout')

@section('content')
<div class="container">
    <table border="2">
        <div class="row-12">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h1 style="color:rgb(0, 140, 255);">View Question Type</h1>
                    </div>
                </div>
                <table border="2">
                    <div class="container">
                        @foreach ($question_type as $row)
                        <tr>
                            <td>Question Id</td>
                            <td>{{ $row->id }}</td>
                        </tr>
                        <tr>
                            <td>Name</td>
                            <td>{{ $row->name}}</td>
                        </tr>
                        {{-- <div class="btn-group">
                            <a href="/editanswer/{{ $row->answer_id }}">
                                <button type="button" class="btn btn-default">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </a>
                        </div> --}}
                        @endforeach
                    </div>
                </table>
            </div>
        </div>
        @endsection