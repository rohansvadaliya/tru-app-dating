@extends('layout')

@section('content')
<div class="container">
    <h1 style="color:rgb(0, 140, 255);">Edit Option Type</h1>
    @foreach ($option_type as $row)
    <form class="form-inline" method="post" action="/option-save?id={{ $row->id }}">
        {{ Session::get('success') }}
        @csrf
        {{-- <div class="form-group">
            <label> Question Type Id</label>
            <input type="text" name="question_id" palceholder="question_id" value="{{ $row->id }}">
        </div>
        <br><br> --}}
        <div class="form-group">
            {{-- <label for="Question Id">question_id</label> --}}
            <input type="hidden" name="question_id" value="{{ $row->question_id}}"
                class="form -control @error('question_id') is-invalid @enderror" id="question_id"
                placeholder="question_id">
            @error ('question_id')
            <span class="eroor invalid-feedback">Please Enter a question Id .</span>
            @enderror
        </div>
        <br><br>
        <div class="form-group">
            <label for="option">Option</label>
            <input type="text" name="option" value="{{ $row->option }}"
                class="form-control @error('option') is-invalid @enderror" id="option" placeholder="option">
            @error('option')
            <span class="error invalid-feedback">Please Enter a Option.</span>
            @enderror
        </div>
        <br><br>
        <div class="form-group">
            <input type="submit" value="submit" class="btn btn-primary">
            {{-- <button onclick="myFunction()">Submit</button> --}}
        </div>
    </form>
    @endforeach
</div>
{{-- <script>
    function myFunction() {
          alert("Edit Question Type Successfully!");
        }
</script> --}}
@endsection