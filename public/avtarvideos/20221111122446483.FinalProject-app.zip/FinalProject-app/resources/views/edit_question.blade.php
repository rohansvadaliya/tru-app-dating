@extends('layout')

@section('content')
<div class="container">
    <h1 style="color:rgb(0, 140, 255);">Edit Question</h1>
    @foreach ($question as $row)
    <form class="form-inline" method="post" action="/question-save">
        {{ Session::get('success') }}

        @csrf
        <div class="form-group">
            <label for="select question type">Question Type</label>
            <select class="form-control" @error ('question_id') is-invalid @enderror name="question_id"
                id="question_id">
                @foreach($question_type as $allquestion)
                <option value="{{ $allquestion->id}}">{{ $allquestion->name }}</option>
                @endforeach
                @error('question_id')
                <span class="error invalid-feedback">Please Enter a Valid Question Id.</span>
                @enderror
            </select>
        </div>
        <br><br>
        <div id="test"></div>

        <br><br>
        <div class="form-group">
            <input type="hidden" name="id" id="id" value="{{ $row->id }}">

            <label> Question </label>
            <input type="text" name="question" value="{{ $row->question}}"
                class="form-control  @error('question') is-invalid @enderror" id="question"
                placeholder="Enter a Question">
            @error('question')
            <span class="error invalid-feedback">Please enter a question.</span>
            @enderror
        </div>
        <br><br>
        <div class="form-group">
            <input type="submit" value="submit" class="btn btn-primary">
            {{-- <button onclick="myFunction()">Submit</button> --}}
        </div>
        <div class="form-group">
            <button type="button" class="btn btn-primary" onclick="return append();" id="add_btn" disabled><i
                class="glyphicon glyphicon-plus"></i></button>
            </div>
    </form>
    @endforeach
</div>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script type="text/javascript" src="dist/js/jquery-2.1.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript">

    $("#question_id").on("change", function(){
        if ($('#question_id').val() == 3)
        {
            $('#add_btn').prop('disabled', false);
        }
    });

    function append(){
        var html='';
            
            html+=" <input type='text' class='form-control' name='option[]'id='option'>";

            $('#test').append(html);
    }

</script>
@endsection